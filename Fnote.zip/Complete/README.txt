===========================================================
               fnote - Fast Note Taker v1.0
===========================================================

fnote is a high-speed micro-logging utility designed for 
developers and power users. 

[ QUICK START ]
1. Run 'setup.bat' (Run as Admin if installing to C:\).
2. The setup creates 'fnote.exe' and a silent 'fn' alias.
3. Restart your Terminal or Win+R to apply the changes.

[ COMMAND LINE (CLI) ]
The 'fn' command is your fastest way to log:
  - Add a note:      fn /tag My quick note
  - Multiple tags:   fn /b /u Critical bug found
  - Undo last note:  fn /undo
  - Search text:     fn /find "api error"
  - Filter today:    fn /today

[ GUI VIEW ]
Type 'fn' or 'fnote' without arguments to open the Viewer.
  - SMART FILTER: Filter notes using Dates or Tags.
  - COLORS: Note rows are colored based on [colors] in fnote.ini.
  - ACTIONS: Right-click any note to Edit, Duplicate, or Delete.

[ CONFIGURATION (fnote.ini) ]
- [tags]: Define shortcuts (e.g., b=Bug, u=Urgent).
- [colors]: Assign BGR colors (Hex). Example: Bug=0x0000FF (Red).
- [autotags]: Use RegEx to automatically tag incoming notes.

[ LICENSE ]
This project is licensed under the GNU GPLv3 License.
===========================================================