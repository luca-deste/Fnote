@echo off
title fnote Setup - Official Winner
echo ===========================================
echo       fnote - Fast Note Taker Setup
echo ===========================================
echo.

:: --- CONFIGURATION ---
set "TARGET_DIR=C:\Tools\fnote"
set "EXE_PATH=%TARGET_DIR%\fnote.exe"
set "LNK_PATH=%TARGET_DIR%\fn.lnk"

:: 1. DIRECTORY CREATION
echo [1/4] Creating directory...
mkdir "%TARGET_DIR%" >nul 2>&1
if not exist "%TARGET_DIR%" (
    echo [ERROR] Access denied. Please Run as Administrator to install in C:\.
    pause
    exit /b
)
if not exist "%TARGET_DIR%\logs" mkdir "%TARGET_DIR%\logs"
echo [OK] Directory structure ready.

:: 2. COPY FILES
echo [2/4] Copying core files...
if exist "fnote.exe" copy /y "fnote.exe" "%TARGET_DIR%\" >nul
if exist "fnote.ini" copy /y "fnote.ini" "%TARGET_DIR%\" >nul
if exist "readme.txt" copy /y "readme.txt" "%TARGET_DIR%\" >nul
echo [OK] Files copied to %TARGET_DIR%.

:: 3. CREATE SILENT ALIAS (.LNK)
echo [3/4] Creating 'fn' shortcut alias...
powershell -NoProfile -Command ^
    "$shell = New-Object -ComObject WScript.Shell; " ^
    "$shortcut = $shell.CreateShortcut('%LNK_PATH%'); " ^
    "$shortcut.TargetPath = '%EXE_PATH%'; " ^
    "$shortcut.Save();"
echo [OK] Silent alias 'fn' is ready.

:: 4. UPDATE USER PATH
echo [4/4] Updating User PATH variable...
powershell -NoProfile -Command ^
    "$target = '%TARGET_DIR%'; " ^
    "$oldPath = [Environment]::GetEnvironmentVariable('Path', 'User'); " ^
    "if ($oldPath -split ';' -notcontains $target) { " ^
    "  [Environment]::SetEnvironmentVariable('Path', $oldPath + ';' + $target, 'User'); " ^
    "  Write-Host '[SUCCESS] PATH updated.' -ForegroundColor Green; " ^
    "} else { " ^
    "  Write-Host '[INFO] fnote is already in PATH.' -ForegroundColor Cyan; " ^
    "}"

echo.
echo ===========================================
echo      INSTALLATION COMPLETE!
echo ===========================================
echo.
echo COMMANDS:
echo - Type 'fn' or 'fnote' in CMD or Win+R.
echo - Example: fn /u Fix this priority bug
echo.
echo IMPORTANT: Restart any open terminal to apply changes.
echo ===========================================
pause